# patlab

# ![patlab-logo](https://raw.githubusercontent.com/sayampradhan/patlab/3d9f516d51495760476e5f44089595e9daa7eb52/docs/docs/assets/patlab-logo.png)

[![PyPI version](https://img.shields.io/pypi/v/patlab.svg)](https://pypi.org/project/patlab/)
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
[![License](https://img.shields.io/github/license/sayampradhan/patlab.svg)](LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/patlab.svg)](https://pypi.org/project/patlab/)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19225415.svg)](https://doi.org/10.5281/zenodo.19225415)
[![Code Style: Black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Linting: Ruff](https://img.shields.io/badge/linting-ruff-blueviolet.svg)](https://github.com/astral-sh/ruff)
[![Issues](https://img.shields.io/github/issues/sayampradhan/patlab)](https://github.com/sayampradhan/patlab/issues)
[![Stars](https://img.shields.io/github/stars/sayampradhan/patlab)](https://github.com/sayampradhan/patlab/stargazers)

**Patlab** is a lightweight Python library for generating common text-based patterns such as squares, pyramids, and triangles with clean and customizable APIs.

It’s designed for beginners, educators, and developers who want a simple way to generate patterns programmatically.

## ✨ Features

- Generate common patterns easily:
  - Squares
  - Pyramids (centered, right-aligned, numeric)
  - Right-angled triangles (classic, inverted)
- Support for:
  - Custom characters
  - Hollow patterns
  - Numeric patterns
- Clean, readable API design
- Minimal dependencies

## 📦 Installation

Install via pip:

```bash
pip install patlab
```

## 🚀 Quick Start
```python
from patlab import *

print(square(3))
print(pyramid(4))
print(right_triangle(4))
```

## 📐 Examples
### Square
```python
from patlab import square as sq

print(sq(4))
print(sq(4, "#"))
```
```
****
****
****
****

####
####
####
####
```

For full documentation, see: https://sayampradhan.github.io/patlab/


## 📜 License
This project is licensed under the terms of the MIT License. See: https://github.com/sayampradhan/patlab/blob/main/LICENSE

## 🤝 Contributing

Contributions are welcome!

If you’d like to improve Patlab, please visit the repository and submit a pull request:
https://github.com/sayampradhan/patlab

## 💡 Inspiration

Patlab is inspired by classic programming exercises used to teach loops, logic, and formatting in Python.

If you've ever written code to print stars (`*`) in shapes like pyramids, triangles, or squares while learning Python, you've already experienced the core idea behind this library.

Patlab builds on those foundational exercises by:

- Turning repetitive pattern-printing logic into reusable functions  
- Providing clean abstractions over nested loops  
- Making it easier to experiment with variations (hollow, numeric, aligned patterns)  
- Helping beginners transition from practice problems to structured code  

It aims to bridge the gap between **learning concepts** and **building reusable tools**, making pattern generation both educational and practical.


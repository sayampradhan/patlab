from typing import Literal
import warnings

Alignment = Literal["left", "right"]
Variant = Literal["classic", "inverted"]


def right_triangle(
    height: int,
    char: str = "*",
    alignment: Alignment = "left",
    inversion: bool = False,
    hollow: bool = False,
    numeric: bool = False,
    space:bool = False
) -> str:
    """
    Generate a right-angled triangle with configurable style.

    This function creates a text-based right triangle of height `n`,
    with options for alignment, inversion, hollow structure, and
    numeric output.

    Parameters
    ----------
    n : int
        Height of the triangle. Must be a positive integer.
    char : str, optional
        Character used to draw the triangle (default is '*').
        Ignored if `numeric=True`.
    alignment : {'left', 'right'}, optional
        Alignment of the triangle:
        - 'left'  : left-aligned triangle (default)
        - 'right' : right-aligned triangle
    inversion : bool, optional
        If True, generates an inverted triangle (top-down).
        Default is False.
    hollow : bool, optional
        If True, generates a hollow triangle (only borders).
        Default is False.
    numeric : bool, optional
        If True, uses numbers instead of characters.
        Each row increases sequentially (e.g., 1, 12, 123).
        Default is False.
    space : bool, optional
        If True, adds spaces between characters or numbers for better readability.
        Default is False.

    Returns
    -------
    str
        A string representation of the generated triangle.

    Raises
    ------
    ValueError
        If `n` is not positive.
    ValueError
        If `char` is specified while `numeric=True`.
    ValueError
        If `alignment` is invalid.

    Examples
    --------
    >>> print(right_triangle(4))
    *
    **
    ***
    ****

    >>> print(right_triangle(4, alignment="right"))
       *
      **
     ***
    ****

    >>> print(right_triangle(4, inversion=True))
    ****
    ***
    **
    *

    >>> print(right_triangle(4, numeric=True))
    1
    12
    123
    1234
    """
    if alignment not in {"left", "right"}:
        raise ValueError(f"Invalid alignment: {alignment}. Must be 'left' or 'right'.")
    if height <= 0:
        raise ValueError("n must be positive")

    if numeric and char != "*":
        raise ValueError("Cannot specify 'char' when numeric=True")
    
    if hollow and height <= 3:
        print("\033[93mWarning: Value should be greater than 3 to create hollow right triangle\033[0m\n")
    lines = []

    if alignment == "right" and space:
        print("\033[93mWarning: Space option may not work well with right alignment\033[0m\n")

    levels = range(1, height + 1)
    if inversion:
        levels = reversed(list(levels))

    for i in levels:
        if numeric:
            if not hollow:
                if space:
                    content = " ".join(str(x) for x in range(1, i + 1))
                else:
                    content = "".join(str(x) for x in range(1, i + 1))
            else:
                if i == 1:
                    content = "1"
                elif i == height:
                    if space:
                        content = " ".join(str(x) for x in range(1, height + 1))
                    else:
                        content = "".join(str(x) for x in range(1, height + 1))
                else:
                    if space:
                        content = "1" + " " * (2 * (i - 2) + 1) + str(i)
                    else:
                        content = "1" + " " * (i - 2) + str(i)

        else:
            if not hollow:
                if space:
                    content = " ".join([char] * i)
                else:
                    content = char * i
            else:
                if i == 1:
                    content = char
                elif i == height:
                    if space:
                        content = " ".join([char] * height)
                    else:
                        content = char * height
                else:
                    if space:
                        content = char + " " * (2 * (i - 2) + 1) + char
                    else:
                        content = char + " " * (i - 2) + char

        if alignment == "left":
            line = content.ljust(height)
        elif alignment == "right":
            line = content.rjust(height)
        else:
            raise ValueError("Invalid alignment")

        lines.append(line)
    return "\n".join(lines)